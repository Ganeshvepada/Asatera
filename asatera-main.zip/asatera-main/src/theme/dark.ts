import {createTheme} from '@mui/material'
const darkTheme = createTheme({
    palette:{
        mode:'dark'
    },
    shape:{

    },
    components:{
        
    }
})

export default darkTheme