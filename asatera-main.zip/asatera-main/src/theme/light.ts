import {createTheme} from '@mui/material'
const lightTheme = createTheme({
    palette:{
        mode:'light'
    },
    shape:{

    },
    components:{
        
    }
})

export default lightTheme