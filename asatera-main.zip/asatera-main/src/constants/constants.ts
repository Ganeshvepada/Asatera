const globalConsts = {
    orgName: "XYZ",
    defaultTheme: "light",
    defaultLogo: "/assets/images/logo192.png",
    logoLight: "/assets/images/logo192.png",
    logoDark: "/assets/images/logo192.png",
  };
  
  export { globalConsts };